package com.example.jewick.imagezoomtest

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.view.ViewCompat.setScaleY
import android.support.v4.view.ViewCompat.setScaleX
import android.view.ScaleGestureDetector
import android.view.MotionEvent
import android.view.View.*
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private var mScaleGestureDetector: ScaleGestureDetector? = null
    private var mScaleFactor = 1.0f
    lateinit var mImageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // initialize the view and the gesture detector
        mImageView = findViewById(R.id.imageView)
        mImageView.setOnClickListener {

        }
        mScaleGestureDetector = ScaleGestureDetector(this, ScaleListener())
    }

    // this redirects all touch events in the activity to the gesture detector
    override fun onTouchEvent(event: MotionEvent): Boolean {
        return mScaleGestureDetector!!.onTouchEvent(event)
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {

        // when a scale gesture is detected, use it to resize the image
        override fun onScale(scaleGestureDetector: ScaleGestureDetector): Boolean {
            mScaleFactor *= scaleGestureDetector.scaleFactor
            mImageView!!.setScaleX(mScaleFactor)
            mImageView!!.setScaleY(mScaleFactor)
            return true
        }
    }

}