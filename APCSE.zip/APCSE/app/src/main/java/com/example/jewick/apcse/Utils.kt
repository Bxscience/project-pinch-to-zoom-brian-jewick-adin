package com.example.jewick.apcse

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream

object Utils {
    fun getImage(image:ByteArray?):Bitmap{
        return BitmapFactory.decodeByteArray(image, 0, image!!.size)
    }
}