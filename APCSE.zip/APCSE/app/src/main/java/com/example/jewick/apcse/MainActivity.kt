package com.example.jewick.apcse

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    //widgets
    lateinit var algorithmBtn: Button
    lateinit var loopBtn: Button
    lateinit var arrayBtn: Button
    lateinit var arrayListBtn: Button
    lateinit var stringBtn: Button
    lateinit var classesBtn: Button
    lateinit var fieldsBtn: Button
    lateinit var recursionBtn: Button
    lateinit var bigOBtn: Button
    lateinit var searchSortBtn: Button
    lateinit var scrollView: ScrollView
    var originalBtnHeight = 0
    var originalBtnWidth = 0
    var btnList : ArrayList<Button>  = ArrayList<Button>()

    lateinit var appcontext: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initWidgets()
        appcontext = applicationContext
    }

    fun initWidgets(){
        algorithmBtn = cBoolean
        loopBtn = cLoop
        arrayBtn = cArray
        arrayListBtn = cArrayList
        stringBtn = cString
        classesBtn = cClasses
        fieldsBtn = cFields
        recursionBtn = cRecursion
        bigOBtn = cBigO
        searchSortBtn = cSS

        originalBtnHeight = algorithmBtn.layoutParams.height
        originalBtnWidth = algorithmBtn.layoutParams.width

        btnList.add(algorithmBtn)
        btnList.add(algorithmBtn)
        btnList.add(loopBtn)
        btnList.add(arrayBtn)
        btnList.add(arrayListBtn)
        btnList.add(stringBtn)
        btnList.add(classesBtn)
        btnList.add(fieldsBtn)
        btnList.add(fieldsBtn)
        btnList.add(recursionBtn)
        btnList.add(bigOBtn)
        btnList.add(searchSortBtn)

        //set methods for buttons
        for(x in btnList){
            var v = x.rootView
            var t = x.text.toString()
            x.setOnClickListener {
                menuBtnAction(v, t)
            }
        }

    }

    fun menuBtnAction(v: View , topic:String){
        val i:Intent = Intent(this,MainActivity2::class.java)
        i.putExtra("TOPIC", topic)
        startActivity(i)
    }

    fun getAppContext() : Context {
        return appcontext
    }

}