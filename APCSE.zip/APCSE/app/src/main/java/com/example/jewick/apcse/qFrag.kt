package com.example.jewick.apcse

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.*
import android.view.ViewGroup
import android.widget.*
import android.view.ScaleGestureDetector
import android.view.MotionEvent
import kotlin.collections.ArrayList
import com.example.jewick.apcse.MainActivity
import kotlinx.android.synthetic.main.qfrag.*


class qFrag : Fragment(){
    //widgets
    private val TAG = "questionFrag"
    lateinit var a: TextView
    lateinit var b: TextView
    lateinit var c: TextView
    lateinit var d: TextView
    lateinit var e: TextView
    lateinit var nextBtn: Button
    lateinit var questionImage: ImageView
    lateinit var panelScrollView: ScrollView
    lateinit var answerPanel: LinearLayout
    lateinit var divider: View
    lateinit var questionTitle: TextView
    lateinit var rsBackground: TextView
    lateinit var rsText: TextView

    var mContext = this.context

    //arrays of buttons and questions
    var ar:ArrayList<TextView> = ArrayList<TextView>()
    var masterList:ArrayList<QuestionObject> = ArrayList<QuestionObject>()
    var topicQuestions:ArrayList<QuestionObject> = ArrayList<QuestionObject>()


    //the number in index
    var currentQuestion = 0
    lateinit var currentQuestionShown: QuestionObject

    //database handling
    lateinit var dbHelper: DBHelper
    private var listener: OnFragmentInteractionListener? = null

    //topic of questions, questions correct, questions wrong
    private var topic: String ?= null
    var numberCorrect = 0
    var numberOfQuestions = 0

    //zoom vars
    private var mScaleGestureDetector: ScaleGestureDetector? = null
    private var mScaleFactor = 1.0f

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        //inflate layout
        val v:View = inflater.inflate(R.layout.qfrag, container, false)
        inflater.inflate(R.layout.qfrag, container, false)
        Log.d(TAG, "question frag view inflated")

        rsBackground = v.findViewById(R.id.rsb)
        rsText = v.findViewById(R.id.rs)

        //implement widgetes
        initButtons(v)
        //zooming ... problem with "this" content
        mScaleGestureDetector = ScaleGestureDetector(context, ScaleListener())

        //retrieve topic
        val args : Bundle ?= arguments
        topic = args?.getString("TOPIC")
        Log.d(TAG, "Topic selected: " + topic)

        //create database
        dbHelper = DBHelper(v.context)
        //get list of all questions from db
        masterList = dbHelper.getAllQuestions()
        topicQuestions = getQuestions(masterList, topic)
        numberOfQuestions = topicQuestions.size

        //start test
        startTest(topicQuestions)

        return v
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
// zooming methods
    fun onTouchEvent(event: MotionEvent): Boolean {
        return mScaleGestureDetector!!.onTouchEvent(event)
    }
// ^
    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {

        // when a scale gesture is detected, use it to resize the image
        override fun onScale(scaleGestureDetector: ScaleGestureDetector): Boolean {
            mScaleFactor *= scaleGestureDetector.scaleFactor
            questionImage!!.setScaleX(mScaleFactor)
            questionImage!!.setScaleY(mScaleFactor)
            return true
        }
    }

    //method to initialize answer buttons
    fun initButtons(v:View){
        a = v.findViewById(R.id.choiceA) as TextView
        b = v.findViewById(R.id.choiceB) as TextView
        c = v.findViewById(R.id.choiceC) as TextView
        d = v.findViewById(R.id.choiceD) as TextView
        e = v.findViewById(R.id.choiceE) as TextView
        questionTitle = v.findViewById(R.id.questionNumberText) as TextView
        divider = v.findViewById(R.id.divider) as View
        panelScrollView = v.findViewById(R.id.answersScrollView) as ScrollView
        answerPanel = v.findViewById(R.id.answerPannel) as LinearLayout

        ar.add(0, a)
        ar.add(1, b)
        ar.add(2, c)
        ar.add(3, d)
        ar.add(4, e)

        nextBtn = v.findViewById(R.id.gifImageView) as Button
        questionImage = v.findViewById(R.id.questionImageView) as ImageView
    }

    //add function to answer buttons
    //answerSelection() called in startTest()
    fun answerSelection(){
        for (x in ar){
            answerSelectedMethod(x)
        }
    }
    //when an answer is clicked the bar will light up red if answered incorrect and green if correct
    //if wrong, the correct answer will be highlighted green
    fun answerSelectedMethod(chosen:TextView){
        chosen.setOnClickListener {
            if(nextBtn.visibility == INVISIBLE){
                chosen.setBackgroundResource(R.color.red)
                chosen.setTextColor(Color.rgb(0, 0, 0))
                for (x in ar) {
                    if (x != chosen) {
                        x.setBackgroundResource(R.color.white)
                        x.setTextColor(Color.rgb(0, 0, 0))
                    }
                }

                var chosenAnswer = chosen.text?.substring(1, 2)
                Log.d("ANSWERING", "CHOSEN ANSWER: " + chosenAnswer)
                Log.d("ANSWERING", "CORRECT ANSWER: " + currentQuestionShown.correctAnswer)
                if (chosenAnswer.equals(currentQuestionShown.correctAnswer)) {
                    chosen.setBackgroundResource(R.color.lime)
                    divider.setBackgroundColor(Color.rgb(0, 255, 0))
                    numberCorrect++
                } else {
                    divider.setBackgroundColor(Color.rgb(255, 0, 0))
                    for (x in ar) {
                        if (x.text?.substring(1, 2).equals(currentQuestionShown.correctAnswer)) {
                            x.setBackgroundResource(R.color.lime)
                        }
                    }
                }
                nextBtn.visibility = VISIBLE
                nextBtn.requestFocus()
            } else {

            }
        }
    }

    //create list questions based on topic
    fun getQuestions(list:ArrayList<QuestionObject>, topic: String?): ArrayList<QuestionObject>{
        var result: ArrayList<QuestionObject> = ArrayList<QuestionObject>()
        for(x in list){
            if(topic.equals(x.category1) || topic.equals(x.category2) || topic.equals(x.category3)){
                result.add(x)
            }
        }
        return result
    }

    fun startTest(list:ArrayList<QuestionObject>){
        var modList = list
        modList.shuffle()

        //0th, i.e, first question in list is showns
        var textTitle = "#" + (currentQuestion+1) + "/" + numberOfQuestions
        questionTitle.setText(textTitle)

        showQuestion(currentQuestion, modList)
        currentQuestionShown = modList.get(currentQuestion)
        answerSelection()

        //everytime nextbutton is clicked, the next question is shown
        nextBtn.setOnClickListener{
            if(currentQuestion == modList.size-1){
                rsBackground.visibility = VISIBLE
                rsText.setText("Your Score was " + numberCorrect + " / " + numberOfQuestions)
                rsText.visibility = VISIBLE
            }
            divider.setBackgroundColor(0)
            if(currentQuestion < modList.size-1) {

                currentQuestion++

                var textTitle = "#" + (currentQuestion+1) + "/" + numberOfQuestions
                questionTitle.setText(textTitle)

                showQuestion(currentQuestion,modList)
                currentQuestionShown = modList.get(currentQuestion)
            }
        }
    }

    fun showQuestion(qn:Int, list:ArrayList<QuestionObject>){
        //TODO: create a results fragment to show results
        if(qn != list.size) {
            a.requestFocus()
            var targetQuestion = list.get(qn)
            var targetImage = Utils.getImage(targetQuestion.Question)
            questionImage.setImageBitmap(targetImage)

            a.setText(targetQuestion.answerA)
            b.setText(targetQuestion.answerB)
            c.setText(targetQuestion.answerC)
            d.setText(targetQuestion.answerD)
            e.setText(targetQuestion.answerE)

            for(x in ar){
                x.setBackgroundResource(R.color.pink)
            }

            nextBtn.visibility = INVISIBLE
            rsText.visibility = INVISIBLE
            rsBackground.visibility = INVISIBLE
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            listener = context
        } else {
            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson [Communicating with Other Fragments]
     * (http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
     */
    interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri)
    }
}